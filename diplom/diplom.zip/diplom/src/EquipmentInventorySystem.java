import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class EquipmentInventorySystem extends JFrame {
    public EquipmentInventorySystem() {
        setTitle("Система учета и инвентаризации техники");
        setSize(800, 600);
        setLocationRelativeTo(null);

        //объявление contentPane
        JPanel contentPane;
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(new CardLayout());

        // создаем меню
        JMenuBar menuBar = new JMenuBar();

        JMenu suiTMenu = new JMenu("СУИТ");

        JMenuItem inventoryTable = new JMenuItem("Таблица Инвентаризации");
        suiTMenu.add(inventoryTable);

        JMenu welcomePage = new JMenu("Домашняя страница");
        suiTMenu.add(welcomePage);

        JMenu fileMenu = new JMenu("Файл");
        menuBar.add(fileMenu);

        JMenuItem exitMenuItem = new JMenuItem("Выход");
        fileMenu.add(exitMenuItem);

        menuBar.add(suiTMenu);
        setJMenuBar(menuBar);

        exitMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                dispose(); // закрыть текущее окно
                System.exit(0); // выход из приложения
            }
        });

        inventoryTable.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                showInventoryTable(); // показать таблицу инвентаризации
            }
        });


        // создаем приветственный экран
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(20, 20, 20, 20);
        JLabel welcomeLabel = new JLabel("Добро пожаловать в Систему учета и инвентаризации техники");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, constraints);
        add(welcomePanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void showWelcomePage() {
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(20, 20, 20, 20);
        JLabel welcomeLabel = new JLabel("Добро пожаловать в Систему учета и инвентаризации техники");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, constraints);
        add(welcomePanel);
    }

    private void showInventoryTable() {
        // создаем таблицу
        DefaultTableModel model = new DefaultTableModel(new Object[][]{
                {"Модель 1", "Наименование 1", "Инвентарный номер 1"},
                {"Модель 2", "Наименование 2", "Инвентарный номер 2"},
                {"Модель 3", "Наименование 3", "Инвентарный номер 3"},
        }, new Object[]{"Модель", "Наименование", "Инвентарный номер"});
        JTable inventoryTable = new JTable(model);

        // создаем панель для таблицы
        JPanel inventoryTablePanel = new JPanel();
        inventoryTablePanel.setLayout(new BorderLayout());
        inventoryTablePanel.add(new JScrollPane(inventoryTable), BorderLayout.CENTER);

        // отображаем таблицу
        setContentPane(inventoryTablePanel);
        revalidate();

        // создаем кнопки для добавления и удаления строк
        JButton addButton = new JButton("Добавить строку");

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.addRow(new Object[]{"", "", ""});
            }
        });

        JButton deleteButton = new JButton("Удалить строку");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] selectedRows = inventoryTable.getSelectedRows();
                for (int i = selectedRows.length - 1; i >= 0; i--) {
                    model.removeRow(selectedRows[i]);
                }
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        inventoryTablePanel.add(buttonPanel, BorderLayout.SOUTH);

        JLabel searchLabel = new JLabel("Поиск: ");
        JTextField searchField = new JTextField(20);
        searchField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchTerm = searchField.getText();
                searchTable(inventoryTable, searchTerm);
            }
        });
        buttonPanel.add(searchLabel);
        buttonPanel.add(searchField);

// добавляем панель на верхнюю панель
        inventoryTablePanel.add(buttonPanel, BorderLayout.NORTH);

// создаем выпадающий список для выбора столбца для сортировки
        String[] columnNames = {"Модель", "Наименование", "Инвентарный номер"};
        JComboBox<String> sortComboBox = new JComboBox<>(columnNames);
        sortComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String sortColumnName = (String) sortComboBox.getSelectedItem();
                int columnIndex = Arrays.asList(columnNames).indexOf(sortColumnName);
                sortTable(inventoryTable, columnIndex);
            }
        });
        buttonPanel.add(sortComboBox);

// отображаем таблицу
        setContentPane(inventoryTablePanel);
        revalidate();
    }

    // метод для поиска по таблице
    private void searchTable(JTable table, String searchTerm) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>((DefaultTableModel) table.getModel());
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchTerm));
        table.setRowSorter(sorter);
    }

    // метод для сортировки таблицы по столбцу
    private void sortTable(JTable table, int columnIndex) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);
        sorter.setSortable(columnIndex, true);
        sorter.toggleSortOrder(columnIndex);
    }

    // метод для получения индекса столбца по его названию
    public int getColumnIndex(JTable table, String columnName) {
        TableColumnModel columnModel = table.getColumnModel();
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            TableColumn column = columnModel.getColumn(i);
            if (column.getHeaderValue().toString().equals(columnName)) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EquipmentInventorySystem::new);
    }
}
